namespace WinFormsApp2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        public void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            int num = Convert.ToInt32(textBox1.Text);

            for (int i = 2; i <= num - 1; i++)
            {
                if (num % i == 0)
                {
                    textBox2.Text = "Not a Prime Number";
                    break;
                }
                if (i == num - 1)
                {
                    textBox2.Text = "Prime Number";
                }
            }
            if (num == 1 || num == 2)
            {
                textBox2.Text = "Prime Number";
            }
        
    }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
    }
}