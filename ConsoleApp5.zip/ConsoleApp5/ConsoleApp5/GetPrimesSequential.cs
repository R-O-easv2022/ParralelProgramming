﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Timers;
using System.Data;
using System.Timers;
using System.Net.Mail;
using System.Diagnostics;


namespace ConsoleApp5
{
    internal class GetPrimes
    {
        class GetPrimesSequential{
            //Ex1
            static void Main(string[] args)
            {
                bool GetPrimesSequential = true;
                Console.WriteLine("Prime Numbers between 1.000.000 and 2.000.000 : ");
                for (int i = 1000000; i <= 2000000; i++)
                {
                    for (int j = 2; j <= 1000000; j++)
                    {
                        if (i != j && i % j == 0)
                        {
                            GetPrimesSequential = false;
                            break;
                        }
                    }
                    if (GetPrimesSequential)
                    {
                        Console.Write("\t" + i);
                    }
                    GetPrimesSequential = true;
                }
                Console.ReadKey();
            }
        }
    }

    class GetPrimesParallel {
        //Ex2
        static void Main(string[] args)
        {
            var sw = Stopwatch.StartNew();
            var collection = new List<int>();

           
            for (int i = 3; i < 2000000; i += 2)
            {
                
                double root = Math.Sqrt(i);

                bool found = false;
                for (int k = 0, count = collection.Count; k < count; k++)
                {
                    int divisor;
                    if ((divisor = collection[k]) > root)
                    {

                        break;
                    }
                    else if ((i % divisor) == 0)
                    {
                       
                        found = true;
                        break;
                    }
                }

                if (found == false)
                {
                    
                    collection.Add(i);
                }
            }

          
            collection.Insert(0, 2);

            Console.WriteLine("Calculation Time:" + sw.ElapsedMilliseconds);
            Console.WriteLine("Numer of Primes: " + collection.Count);
            Console.ReadKey();
        }

    }
}



